<?php
	$conn=mysqli_connect('localhost','root','','remain');
	if(!$conn)
	{
		echo "Unable to connect";
	}
	
?>