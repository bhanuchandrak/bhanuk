Features of our app <br>
Schedule for us, we will remind you. <br>
You can Acess from any where. <br>
Automatically sends notifications for that particular time and date. <br>
You can also schedule for your friends & family members. <br>
<a href="https://knrblj.xyz/app">knrblj.xyz/app</a>

